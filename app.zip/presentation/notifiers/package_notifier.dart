import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:jaldevi_hd_music_book_program/data/models/result.dart';
import 'package:jaldevi_hd_music_book_program/data/services/package_service.dart';
import 'package:jaldevi_hd_music_book_program/domain/entities/package.dart';

// Provider for the PackageNotifier
final packageNotifierProvider = StateNotifierProvider<PackageNotifier, Result<List<Package>>>((ref) {
  return PackageNotifier(ref.watch(packageServiceProvider));
});

class PackageNotifier extends StateNotifier<Result<List<Package>>> {
  final PackageService _packageService;

  PackageNotifier(this._packageService) : super(const Result.initial()) {
    getPackages();
  }

  Future<void> getPackages() async {
    state = const Result.loading();
    try {
      final packages = await _packageService.getPackages();
      state = Result.success(packages);
    } catch (e) {
      state = Result.error('Could not fetch packages: ${e.toString()}');
    }
  }
}
