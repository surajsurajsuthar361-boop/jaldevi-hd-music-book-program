'''import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:jaldevi_hd_music_book_program/data/services/music_book_service.dart';
import 'package:jaldevi_hd_music_book_program/presentation/notifiers/music_book_state.dart';

final musicBookNotifierProvider = StateNotifierProvider<MusicBookNotifier, MusicBookState>((ref) {
  return MusicBookNotifier(MusicBookService());
});

class MusicBookNotifier extends StateNotifier<MusicBookState> {
  final MusicBookService _musicBookService;

  MusicBookNotifier(this._musicBookService) : super(const MusicBookInitial());

  Future<void> fetchMusicBook() async {
    state = const MusicBookLoading();
    try {
      final entries = await _musicBookService.getMusicBookEntries();
      state = MusicBookSuccess(entries);
    } catch (e) {
      state = MusicBookError(e.toString());
    }
  }
}
''