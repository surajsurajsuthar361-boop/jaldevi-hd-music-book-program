'''import 'package:jaldevi_hd_music_book_program/domain/entities/music_book_entry.dart';

abstract class MusicBookState {
  const MusicBookState();
}

class MusicBookInitial extends MusicBookState {
  const MusicBookInitial();
}

class MusicBookLoading extends MusicBookState {
  const MusicBookLoading();
}

class MusicBookSuccess extends MusicBookState {
  final List<MusicBookEntry> entries;
  const MusicBookSuccess(this.entries);
}

class MusicBookError extends MusicBookState {
  final String message;
  const MusicBookError(this.message);
}
''