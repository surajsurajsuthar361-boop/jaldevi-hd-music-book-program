import 'package:flutter/material.dart';
import 'package:jaldevi_hd_music_book_program/data/data.dart';
import 'package:jaldevi_hd_music_book_program/presentation/screens/packages/package_details_screen.dart';

class PackageCarousel extends StatelessWidget {
  const PackageCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    final packages = AppData.packages;

    return SizedBox(
      height: 220,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: packages.length,
        itemBuilder: (context, index) {
          final package = packages[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PackageDetailsScreen(package: package),
                ),
              );
            },
            child: Card(
              margin: const EdgeInsets.symmetric(horizontal: 8.0),
              child: SizedBox(
                width: 160,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(package.imageUrl, height: 120, width: double.infinity, fit: BoxFit.cover),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(package.name, style: Theme.of(context).textTheme.subtitle1, overflow: TextOverflow.ellipsis),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text('₹${package.price.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodyText2),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
