import 'package:flutter/material.dart';

import 'package:jaldevi_hd_music_book_program/data/data.dart';

class UpcomingBookingCard extends StatelessWidget {
  const UpcomingBookingCard({super.key});

  @override
  Widget build(BuildContext context) {
    final upcomingBooking = AppData.bookings
        .firstWhere((booking) => booking.status == 'Upcoming', orElse: () => AppData.bookings.first);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Upcoming Booking', style: Theme.of(context).textTheme.headline6),
            const SizedBox(height: 16.0),
            ListTile(
              leading: const Icon(Icons.music_note),
              title: Text(upcomingBooking.package.name),
              subtitle: Text('On ${upcomingBooking.eventDate.toLocal()}'.split(' ')[0]),
              trailing: Text(upcomingBooking.status, style: TextStyle(color: Colors.orange.shade700)),
            ),
            const SizedBox(height: 8.0),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  // TODO: Navigate to booking details screen
                },
                child: const Text('View Details'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
