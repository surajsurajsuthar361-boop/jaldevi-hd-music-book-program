import 'package:flutter/material.dart';

class HomeContent extends StatelessWidget {
  final VoidCallback onViewAllPackages;

  const HomeContent({super.key, required this.onViewAllPackages});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        // Search Bar
        TextField(
          decoration: InputDecoration(
            hintText: 'Search for packages...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
          ),
        ),
        const SizedBox(height: 24.0),

        // Featured Packages Section
        Text(
          'Featured Packages',
          style: Theme.of(context).textTheme.headline6,
        ),
        const SizedBox(height: 16.0),
        // Placeholder for featured packages
        // In a real app, this would be a horizontal list view
        Container(
          height: 150,
          color: Colors.grey[200],
          child: const Center(
            child: Text('Featured Packages Carousel'),
          ),
        ),
        const SizedBox(height: 24.0),

        // View All Packages Button
        ElevatedButton(
          onPressed: onViewAllPackages,
          child: const Text('View All Packages'),
        ),
      ],
    );
  }
}
