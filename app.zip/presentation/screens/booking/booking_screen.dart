'''import 'package:flutter/material.dart';
import 'package:jaldevi_hd_music_book_program/presentation/screens/booking/booking_form.dart';

class BookingScreen extends StatelessWidget {
  const BookingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book a Session'),
      ),
      body: const BookingForm(),
    );
  }
}
''