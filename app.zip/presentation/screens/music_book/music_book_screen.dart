'''import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:jaldevi_hd_music_book_program/presentation/notifiers/music_book_notifier.dart';
import 'package:jaldevi_hd_music_book_program/presentation/notifiers/music_book_state.dart';

class MusicBookScreen extends ConsumerWidget {
  const MusicBookScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final musicBookState = ref.watch(musicBookNotifierProvider);

    // Fetch the music book when the widget is first built
    ref.read(musicBookNotifierProvider.notifier).fetchMusicBook();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Music Book'),
      ),
      body: _buildBody(musicBookState),
    );
  }

  Widget _buildBody(MusicBookState state) {
    if (state is MusicBookLoading) {
      return const Center(child: CircularProgressIndicator());
    } else if (state is MusicBookSuccess) {
      return ListView.builder(
        itemCount: state.entries.length,
        itemBuilder: (context, index) {
          final entry = state.entries[index];
          return ListTile(
            title: Text(entry.title),
            subtitle: Text(entry.artist),
          );
        },
      );
    } else if (state is MusicBookError) {
      return Center(child: Text(state.message));
    } else {
      return const Center(child: Text('Initial State'));
    }
  }
}
''